# LCRG reproducibility freeze package

This archive is the numerical provenance package for the manuscript

**From Orthogonal Invariance to Walsh Spectral Multipliers:
Lead-Conditioned Reference Geometry and Exact Attribution for 12-Lead ECG**

## Chronology

1. PTB-XL folds 1-8: normal-reference estimation.
2. Fold 9: validation/model-selection stage.
3. Primary full-covariance model and NORM-vs-HYP task locked.
4. Fold 10 opened once for confirmatory evaluation.
5. Fixed diagonal-Walsh, PCA, and Isolation-Forest comparators evaluated
   without fold-10 tuning.
6. This package freezes all final numerical outputs.

## Important

The diagonal-Walsh comparator outperformed the prespecified full-covariance
primary model on HYP. This result is retained exactly as observed and was
not used to retroactively redefine the confirmatory primary analysis.
